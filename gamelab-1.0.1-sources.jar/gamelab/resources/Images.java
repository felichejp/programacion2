package gamelab.resources;

import gamelab.graphics.GameImage;
import gamelab.internal.graphics.InternalImages;
import java.util.Locale;

/**
 * Carga imágenes PNG incluidas en el classpath del juego.
 *
 * <p>Si el archivo está en {@code resources/images/nave.png} y {@code resources} se agrega
 * como raíz del classpath, se carga con {@code Images.load("/images/nave.png")}. La barra
 * inicial es obligatoria y la extensión se compara sin distinguir mayúsculas.</p>
 */
public final class Images {
    private Images() {
    }

    /**
     * Carga una imagen PNG desde una ruta absoluta del classpath.
     *
     * @param path ruta absoluta del recurso, iniciada con {@code /}
     * @return imagen cargada
     * @throws IllegalArgumentException si la ruta es nula, relativa o no termina en
     *         {@code .png}
     * @throws gamelab.errors.ResourceException si el recurso no existe, no es un PNG válido
     *         o no puede leerse
     */
    public static GameImage load(String path) {
        validatePath(path);
        return InternalImages.load(path);
    }

    private static void validatePath(String path) {
        if (path == null) {
            throw new IllegalArgumentException("La ruta de la imagen no puede ser nula.");
        }
        if (!path.startsWith("/")) {
            throw new IllegalArgumentException("La ruta de la imagen debe comenzar con '/'.");
        }
        if (!path.toLowerCase(Locale.ROOT).endsWith(".png")) {
            throw new IllegalArgumentException("La imagen debe tener la extensión .png.");
        }
    }
}
