package gamelab.core;

import gamelab.errors.GameConfigurationException;
import gamelab.errors.GameExecutionException;
import gamelab.graphics.GameCanvas;
import gamelab.input.Input;
import gamelab.internal.graphics.GameRuntime;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Clase base de un juego con ventana, teclado y ciclo de vida administrados por GameLab.
 *
 * <p>La resolución indicada al construir el juego es lógica y se conserva al redimensionar
 * la ventana. El origen del lienzo está en la esquina superior izquierda; el eje {@code x}
 * crece hacia la derecha y el eje {@code y}, hacia abajo. GameLab intenta ejecutar 60 pares
 * de {@link #update()} y {@link #draw(GameCanvas)} por segundo en un único hilo dedicado.</p>
 *
 * <p>Ejemplo mínimo:</p>
 * <pre>{@code
 * public final class MiJuego extends Game {
 *     public MiJuego() { super("Mi juego", 800, 600); }
 *     public void start() { }
 *     public void update() { if (input().isKeyPressed(Key.ESCAPE)) stop(); }
 *     public void draw(GameCanvas canvas) { canvas.clear(Color.BLACK); }
 *     public static void main(String[] args) { new MiJuego().run(); }
 * }
 * }</pre>
 */
public abstract class Game {
    private final String title;
    private final int width;
    private final int height;
    private final GameRuntime.Runner runner;
    private final AtomicBoolean launched = new AtomicBoolean();
    private final AtomicBoolean running = new AtomicBoolean();
    private volatile Input input = new Input(Set.of(), Set.of());

    /**
     * Crea un juego con título y resolución lógica constantes.
     *
     * @param title título no vacío de la ventana
     * @param width ancho lógico positivo, en píxeles
     * @param height alto lógico positivo, en píxeles
     * @throws GameConfigurationException si el título es nulo o está en blanco, o si una
     *         dimensión no es positiva
     */
    protected Game(String title, int width, int height) {
        this(title, width, height, GameRuntime.windowed());
    }

    Game(String title, int width, int height, GameRuntime.Runner runner) {
        if (title == null || title.isBlank()) {
            throw new GameConfigurationException("El título del juego no puede estar vacío.");
        }
        if (width <= 0 || height <= 0) {
            throw new GameConfigurationException("El ancho y el alto del juego deben ser positivos.");
        }
        this.title = title;
        this.width = width;
        this.height = height;
        this.runner = Objects.requireNonNull(runner, "El motor del juego no puede ser nulo.");
    }

    /**
     * Inicializa el estado del juego exactamente una vez, antes de la primera actualización.
     * Si el método lanza una excepción o error, {@link #run()} termina con una
     * {@link GameExecutionException} que identifica la fase {@code start()}.
     */
    public abstract void start();

    /**
     * Actualiza el estado del juego durante un paso fijo de aproximadamente 1/60 de segundo.
     * Esta fase es el lugar habitual para consultar {@link #input()} y cambiar posiciones.
     * Si lanza una excepción o error, {@link #run()} termina con una
     * {@link GameExecutionException} que identifica la fase {@code update()}.
     */
    public abstract void update();

    /**
     * Dibuja el estado actual sobre la superficie lógica.
     *
     * Las coordenadas y dimensiones se expresan en píxeles lógicos.
     * Si el método lanza una excepción o error, {@link #run()} termina con una
     * {@link GameExecutionException} que identifica la fase {@code draw()}.
     *
     * @param canvas superficie lógica administrada por GameLab; nunca es nula
     */
    public abstract void draw(GameCanvas canvas);

    /**
     * Inicia el juego y bloquea el hilo llamador hasta que se cierra la ventana, se invoca
     * {@link #stop()} o ocurre un fallo. Cada instancia solo puede ejecutarse una vez.
     *
     * @throws IllegalStateException si esta instancia ya se ejecutó
     * @throws GameExecutionException si falla un callback, se interrumpe la espera o se intenta
     *         ejecutar una ventana desde el hilo de eventos de Swing
     */
    public final void run() {
        if (!launched.compareAndSet(false, true)) {
            throw new IllegalStateException("Cada instancia de Game solo puede ejecutarse una vez.");
        }

        running.set(true);
        try {
            runner.run(
                    title,
                    width,
                    height,
                    new GameRuntime.Lifecycle() {
                        @Override
                        public void start() {
                            Game.this.start();
                        }

                        @Override
                        public void update(Input nextInput) {
                            input = nextInput;
                            Game.this.update();
                        }

                        @Override
                        public void draw(GameCanvas canvas) {
                            Game.this.draw(canvas);
                        }
                    },
                    running::get,
                    this::stop);
        } finally {
            running.set(false);
        }
    }

    /**
     * Solicita terminar el juego y retorna inmediatamente.
     * La ejecución finaliza de forma cooperativa al concluir el callback en curso; llamar este
     * método antes o después de {@link #run()} no produce un error.
     */
    public final void stop() {
        running.set(false);
    }

    /**
     * Obtiene la instantánea de teclado capturada antes de la actualización actual.
     *
     * En {@link #start()} todavía representa una instantánea vacía. En {@link #update()}
     * corresponde al paso actual.
     *
     * @return entrada inmutable del paso actual
     */
    protected final Input input() {
        return input;
    }

    /**
     * Obtiene el ancho lógico del juego.
     *
     * @return ancho lógico positivo, en píxeles
     */
    protected final int width() {
        return width;
    }

    /**
     * Obtiene el alto lógico del juego.
     *
     * @return alto lógico positivo, en píxeles
     */
    protected final int height() {
        return height;
    }
}
