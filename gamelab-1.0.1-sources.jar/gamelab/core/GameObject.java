package gamelab.core;

import gamelab.graphics.GameCanvas;

/**
 * Elemento que participa en un {@link World} y recibe sus actualizaciones y dibujos.
 *
 * <p>Por ejemplo, una nave puede cambiar sus coordenadas en {@link #update()} y dibujarse
 * con esas coordenadas en {@link #draw(GameCanvas)}. El propio objeto decide las unidades de
 * su estado; al dibujar, GameLab utiliza píxeles lógicos con origen arriba a la izquierda.</p>
 */
public interface GameObject {

    /**
     * Actualiza el estado del objeto durante un ciclo del juego.
     * Cuando lo invoca {@link World#update()}, cualquier excepción se propaga al llamador.
     */
    void update();

    /**
     * Dibuja el objeto sobre el lienzo indicado.
     *
     * @param canvas lienzo donde se dibuja el objeto; normalmente es el recibido por
     *         {@link Game#draw(GameCanvas)}
     */
    void draw(GameCanvas canvas);
}
