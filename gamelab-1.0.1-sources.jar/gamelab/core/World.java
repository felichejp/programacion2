package gamelab.core;

import gamelab.graphics.GameCanvas;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Conjunto ordenado de objetos que se actualizan y dibujan en cada ciclo.
 *
 * <p>Los cambios solicitados durante una actualización o dibujo se aplican
 * al terminar ese recorrido. Así, un objeto puede agregar un proyectil en su
 * {@link GameObject#update()} sin modificar la colección que se está recorriendo.</p>
 */
public final class World {
    private final List<GameObject> objects = new ArrayList<>();
    private final List<Runnable> pendingOperations = new ArrayList<>();
    private boolean traversing;

    /** Crea un mundo vacío. */
    public World() {
    }

    /**
     * Agrega un objeto al final del mundo. Se permite agregar la misma instancia más de una vez.
     * Si se llama durante {@link #update()} o {@link #draw(GameCanvas)}, el alta se hace efectiva
     * al finalizar ese recorrido.
     *
     * @param object objeto que se agregará
     * @throws NullPointerException si {@code object} es nulo
     */
    public void add(GameObject object) {
        GameObject checkedObject = Objects.requireNonNull(object, "El objeto no puede ser nulo.");
        executeOrDefer(() -> objects.add(checkedObject));
    }

    /**
     * Elimina la primera coincidencia del objeto, comparada por identidad ({@code ==}).
     * Si se llama durante un recorrido, la baja se hace efectiva al finalizarlo.
     *
     * @param object objeto que se eliminará
     * @throws NullPointerException si {@code object} es nulo
     */
    public void remove(GameObject object) {
        GameObject checkedObject = Objects.requireNonNull(object, "El objeto no puede ser nulo.");
        executeOrDefer(() -> removeFirstByIdentity(checkedObject));
    }

    /**
     * Elimina todos los objetos del mundo, o programa la operación para después del recorrido
     * actual.
     */
    public void clear() {
        executeOrDefer(objects::clear);
    }

    /**
     * Actualiza cada objeto del mundo en orden de inserción. Si un callback falla, se propaga
     * su excepción y se descartan las altas o bajas que quedaron pendientes en ese recorrido.
     */
    public void update() {
        traverse(GameObject::update);
    }

    /**
     * Dibuja cada objeto del mundo en orden de inserción.
     *
     * Si un callback falla, se propaga su excepción y se descartan las operaciones pendientes.
     *
     * @param canvas lienzo que se entrega, sin modificar, a cada objeto
     */
    public void draw(GameCanvas canvas) {
        traverse(object -> object.draw(canvas));
    }

    /**
     * Obtiene la cantidad actual de objetos del mundo.
     *
     * @return número de objetos presentes
     */
    public int size() {
        return objects.size();
    }

    private void executeOrDefer(Runnable operation) {
        if (traversing) {
            pendingOperations.add(operation);
        } else {
            operation.run();
        }
    }

    private void removeFirstByIdentity(GameObject object) {
        for (int index = 0; index < objects.size(); index++) {
            if (objects.get(index) == object) {
                objects.remove(index);
                return;
            }
        }
    }

    private void traverse(ObjectTraversal traversal) {
        traversing = true;
        try {
            for (GameObject object : objects) {
                traversal.apply(object);
            }
            traversing = false;
            pendingOperations.forEach(Runnable::run);
            pendingOperations.clear();
        } catch (RuntimeException | Error failure) {
            traversing = false;
            pendingOperations.clear();
            throw failure;
        }
    }

    @FunctionalInterface
    private interface ObjectTraversal {
        void apply(GameObject object);
    }
}
