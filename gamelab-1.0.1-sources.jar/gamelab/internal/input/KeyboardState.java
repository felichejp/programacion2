package gamelab.internal.input;

import gamelab.input.Input;
import gamelab.input.Key;
import java.util.EnumSet;

/**
 * Conserva el estado físico del teclado y produce instantáneas por cuadro.
 */
public final class KeyboardState {
    private final Object lock = new Object();
    private final EnumSet<Key> physicalDown = EnumSet.noneOf(Key.class);
    private final EnumSet<Key> previousFrame = EnumSet.noneOf(Key.class);
    private final EnumSet<Key> down = EnumSet.noneOf(Key.class);
    private final EnumSet<Key> pressed = EnumSet.noneOf(Key.class);

    /**
     * Registra una tecla física presionada e ignora códigos desconocidos.
     *
     * @param keyCode código de tecla recibido por la ventana
     */
    public void press(int keyCode) {
        Key key = KeyMap.fromKeyCode(keyCode);
        if (key == null) {
            return;
        }
        synchronized (lock) {
            physicalDown.add(key);
        }
    }

    /**
     * Registra una tecla física liberada e ignora códigos desconocidos.
     *
     * @param keyCode código de tecla recibido por la ventana
     */
    public void release(int keyCode) {
        Key key = KeyMap.fromKeyCode(keyCode);
        if (key == null) {
            return;
        }
        synchronized (lock) {
            physicalDown.remove(key);
        }
    }

    /**
     * Limpia todas las teclas, por ejemplo cuando la ventana pierde el foco.
     */
    public void clear() {
        synchronized (lock) {
            physicalDown.clear();
            previousFrame.clear();
            down.clear();
            pressed.clear();
        }
    }

    /**
     * Captura de forma atómica el estado para una actualización del juego.
     *
     * @return instantánea inmutable del cuadro actual
     */
    public Input captureFrame() {
        synchronized (lock) {
            pressed.clear();
            pressed.addAll(physicalDown);
            pressed.removeAll(previousFrame);

            down.clear();
            down.addAll(physicalDown);

            previousFrame.clear();
            previousFrame.addAll(physicalDown);

            return new Input(down, pressed);
        }
    }
}
