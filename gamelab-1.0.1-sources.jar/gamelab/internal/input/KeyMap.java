package gamelab.internal.input;

import gamelab.input.Key;
import java.awt.event.KeyEvent;

final class KeyMap {
    private KeyMap() {
    }

    static Key fromKeyCode(int keyCode) {
        return switch (keyCode) {
            case KeyEvent.VK_A -> Key.A;
            case KeyEvent.VK_B -> Key.B;
            case KeyEvent.VK_C -> Key.C;
            case KeyEvent.VK_D -> Key.D;
            case KeyEvent.VK_E -> Key.E;
            case KeyEvent.VK_F -> Key.F;
            case KeyEvent.VK_G -> Key.G;
            case KeyEvent.VK_H -> Key.H;
            case KeyEvent.VK_I -> Key.I;
            case KeyEvent.VK_J -> Key.J;
            case KeyEvent.VK_K -> Key.K;
            case KeyEvent.VK_L -> Key.L;
            case KeyEvent.VK_M -> Key.M;
            case KeyEvent.VK_N -> Key.N;
            case KeyEvent.VK_O -> Key.O;
            case KeyEvent.VK_P -> Key.P;
            case KeyEvent.VK_Q -> Key.Q;
            case KeyEvent.VK_R -> Key.R;
            case KeyEvent.VK_S -> Key.S;
            case KeyEvent.VK_T -> Key.T;
            case KeyEvent.VK_U -> Key.U;
            case KeyEvent.VK_V -> Key.V;
            case KeyEvent.VK_W -> Key.W;
            case KeyEvent.VK_X -> Key.X;
            case KeyEvent.VK_Y -> Key.Y;
            case KeyEvent.VK_Z -> Key.Z;
            case KeyEvent.VK_0 -> Key.NUM_0;
            case KeyEvent.VK_1 -> Key.NUM_1;
            case KeyEvent.VK_2 -> Key.NUM_2;
            case KeyEvent.VK_3 -> Key.NUM_3;
            case KeyEvent.VK_4 -> Key.NUM_4;
            case KeyEvent.VK_5 -> Key.NUM_5;
            case KeyEvent.VK_6 -> Key.NUM_6;
            case KeyEvent.VK_7 -> Key.NUM_7;
            case KeyEvent.VK_8 -> Key.NUM_8;
            case KeyEvent.VK_9 -> Key.NUM_9;
            case KeyEvent.VK_UP -> Key.UP;
            case KeyEvent.VK_DOWN -> Key.DOWN;
            case KeyEvent.VK_LEFT -> Key.LEFT;
            case KeyEvent.VK_RIGHT -> Key.RIGHT;
            case KeyEvent.VK_SPACE -> Key.SPACE;
            case KeyEvent.VK_ENTER -> Key.ENTER;
            case KeyEvent.VK_ESCAPE -> Key.ESCAPE;
            case KeyEvent.VK_SHIFT -> Key.SHIFT;
            case KeyEvent.VK_CONTROL -> Key.CONTROL;
            case KeyEvent.VK_ALT -> Key.ALT;
            default -> null;
        };
    }
}
