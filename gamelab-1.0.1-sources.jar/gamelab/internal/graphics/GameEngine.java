package gamelab.internal.graphics;

import gamelab.errors.GameExecutionException;
import gamelab.input.Input;
import gamelab.internal.FixedStepLoop;
import gamelab.internal.NanoClock;
import gamelab.internal.input.KeyboardState;
import java.awt.image.BufferedImage;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BooleanSupplier;
import javax.swing.SwingUtilities;

/** Coordina ventana, entrada, callbacks y ciclo fijo desde un hilo dedicado. */
final class GameEngine {
    private static final String GAME_THREAD_NAME = "GameLab-game-loop";

    private final String title;
    private final int width;
    private final int height;
    private final GameRuntime.Lifecycle lifecycle;
    private final BooleanSupplier running;
    private final Runnable requestStop;
    private final NanoClock clock;
    private final int frameLimit;
    private final boolean windowed;
    private final FrameFactory frameFactory;
    private final KeyboardState keyboard = new KeyboardState();

    GameEngine(
            String title,
            int width,
            int height,
            GameRuntime.Lifecycle lifecycle,
            BooleanSupplier running,
            Runnable requestStop,
            NanoClock clock,
            int frameLimit,
            boolean windowed) {
        this(
                title,
                width,
                height,
                lifecycle,
                running,
                requestStop,
                clock,
                frameLimit,
                windowed,
                (frameWidth, frameHeight) -> new BufferedImage(
                        frameWidth, frameHeight, BufferedImage.TYPE_INT_ARGB));
    }

    GameEngine(
            String title,
            int width,
            int height,
            GameRuntime.Lifecycle lifecycle,
            BooleanSupplier running,
            Runnable requestStop,
            NanoClock clock,
            int frameLimit,
            boolean windowed,
            FrameFactory frameFactory) {
        this.title = Objects.requireNonNull(title, "El título no puede ser nulo.");
        this.width = width;
        this.height = height;
        this.lifecycle = Objects.requireNonNull(lifecycle, "El ciclo de vida no puede ser nulo.");
        this.running = Objects.requireNonNull(running, "La bandera de ejecución no puede ser nula.");
        this.requestStop = Objects.requireNonNull(requestStop, "La solicitud de cierre no puede ser nula.");
        this.clock = Objects.requireNonNull(clock, "El reloj no puede ser nulo.");
        this.frameLimit = frameLimit;
        this.windowed = windowed;
        this.frameFactory = Objects.requireNonNull(
                frameFactory, "La fábrica de cuadros no puede ser nula.");
    }

    void run() {
        if (windowed && SwingUtilities.isEventDispatchThread()) {
            throw new GameExecutionException(
                    "Game.run() no puede ejecutarse desde el hilo de eventos de Swing.");
        }
        GameWindow window = windowed
                ? new GameWindow(title, width, height, keyboard, requestStop)
                : null;
        AtomicReference<Throwable> failure = new AtomicReference<>();
        Thread gameThread = new Thread(
                () -> runOnGameThread(window, failure), GAME_THREAD_NAME);

        try {
            gameThread.start();
            join(gameThread);
        } finally {
            if (window != null) {
                window.close();
            }
        }

        rethrow(failure.get());
    }

    private void runOnGameThread(GameWindow window, AtomicReference<Throwable> failure) {
        Java2DGameCanvas canvas = null;
        try {
            BufferedImage frame;
            try {
                frame = frameFactory.create(width, height);
                canvas = new Java2DGameCanvas(frame);
            } catch (RuntimeException | Error cause) {
                throw new GameExecutionException(
                        "Error durante la inicialización del motor.", cause);
            }

            Java2DGameCanvas activeCanvas = canvas;
            AtomicInteger completedUpdates = new AtomicInteger();
            invokePhase("start()", lifecycle::start);
            FixedStepLoop loop = new FixedStepLoop(
                    clock,
                    () -> update(completedUpdates),
                    () -> draw(activeCanvas, frame, window),
                    running);
            loop.run();
        } catch (RuntimeException | Error caughtFailure) {
            failure.set(caughtFailure);
            requestStop.run();
        } finally {
            if (canvas != null) {
                canvas.close();
            }
            if (window != null) {
                window.close();
            }
        }
    }

    @FunctionalInterface
    interface FrameFactory {
        BufferedImage create(int width, int height);
    }

    private void update(AtomicInteger completedUpdates) {
        Input input = keyboard.captureFrame();
        invokePhase("update()", () -> lifecycle.update(input));
        if (frameLimit > 0 && completedUpdates.incrementAndGet() >= frameLimit) {
            requestStop.run();
        }
    }

    private void draw(Java2DGameCanvas canvas, BufferedImage frame, GameWindow window) {
        invokePhase("draw()", () -> lifecycle.draw(canvas));
        if (window != null) {
            window.present(frame);
        }
    }

    private static void invokePhase(String phase, Runnable callback) {
        try {
            callback.run();
        } catch (RuntimeException | Error cause) {
            throw new GameExecutionException("Error durante " + phase, cause);
        }
    }

    private void join(Thread gameThread) {
        try {
            gameThread.join();
        } catch (InterruptedException interruption) {
            requestStop.run();
            gameThread.interrupt();
            waitUntilTerminated(gameThread);
            Thread.currentThread().interrupt();
            throw new GameExecutionException("La ejecución del juego fue interrumpida.", interruption);
        }
    }

    private static void waitUntilTerminated(Thread gameThread) {
        while (gameThread.isAlive()) {
            try {
                gameThread.join();
            } catch (InterruptedException repeatedInterruption) {
                gameThread.interrupt();
            }
        }
    }

    private static void rethrow(Throwable failure) {
        if (failure instanceof RuntimeException runtimeFailure) {
            throw runtimeFailure;
        }
        if (failure instanceof Error error) {
            throw error;
        }
    }
}
