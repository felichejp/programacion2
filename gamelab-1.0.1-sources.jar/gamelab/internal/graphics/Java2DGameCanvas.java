package gamelab.internal.graphics;

import gamelab.graphics.Color;
import gamelab.graphics.GameCanvas;
import gamelab.graphics.GameImage;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.Objects;

/** Adaptador interno que dibuja un {@link GameCanvas} mediante Java2D. */
final class Java2DGameCanvas implements GameCanvas {
    private static final String FONT_FAMILY = "SansSerif";

    private final BufferedImage surface;
    private final Graphics2D graphics;
    private final Runnable disposer;
    private boolean closed;

    /**
     * Crea un lienzo sobre una imagen en memoria.
     *
     * @param surface imagen que recibirá los dibujos
     */
    Java2DGameCanvas(BufferedImage surface) {
        this(surface, createGraphics(surface));
    }

    private Java2DGameCanvas(BufferedImage surface, Graphics2D graphics) {
        this(surface, graphics, graphics::dispose);
    }

    Java2DGameCanvas(BufferedImage surface, Graphics2D graphics, Runnable disposer) {
        this.surface = Objects.requireNonNull(surface, "La superficie no puede ser nula.");
        this.graphics = Objects.requireNonNull(graphics, "El contexto gráfico no puede ser nulo.");
        this.disposer = Objects.requireNonNull(disposer, "La liberación gráfica no puede ser nula.");
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics.setRenderingHint(
                RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        graphics.setColor(toAwtColor(Color.WHITE));
    }

    synchronized void close() {
        if (closed) {
            return;
        }
        closed = true;
        disposer.run();
    }

    @Override
    public void clear(Color color) {
        java.awt.Color drawingColor = graphics.getColor();
        try {
            graphics.setColor(toAwtColor(color));
            graphics.fillRect(0, 0, width(), height());
        } finally {
            graphics.setColor(drawingColor);
        }
    }

    @Override
    public void setColor(Color color) {
        graphics.setColor(toAwtColor(color));
    }

    @Override
    public void drawRectangle(double x, double y, double width, double height) {
        graphics.drawRect(pixel(x), pixel(y), pixel(width), pixel(height));
    }

    @Override
    public void fillRectangle(double x, double y, double width, double height) {
        graphics.fillRect(pixel(x), pixel(y), pixel(width), pixel(height));
    }

    @Override
    public void drawCircle(double centerX, double centerY, double radius) {
        graphics.drawOval(
                pixel(centerX - radius),
                pixel(centerY - radius),
                pixel(radius * 2),
                pixel(radius * 2));
    }

    @Override
    public void fillCircle(double centerX, double centerY, double radius) {
        graphics.fillOval(
                pixel(centerX - radius),
                pixel(centerY - radius),
                pixel(radius * 2),
                pixel(radius * 2));
    }

    @Override
    public void drawLine(double x1, double y1, double x2, double y2) {
        graphics.drawLine(pixel(x1), pixel(y1), pixel(x2), pixel(y2));
    }

    @Override
    public void drawText(String text, double x, double y, int size) {
        graphics.setFont(new Font(FONT_FAMILY, Font.PLAIN, size));
        graphics.drawString(Objects.requireNonNull(text, "El texto no puede ser nulo."), pixel(x), pixel(y));
    }

    @Override
    public void drawImage(GameImage image, double x, double y) {
        graphics.drawImage(bufferedImage(image), pixel(x), pixel(y), null);
    }

    @Override
    public void drawImage(GameImage image, double x, double y, double width, double height) {
        graphics.drawImage(
                bufferedImage(image), pixel(x), pixel(y), pixel(width), pixel(height), null);
    }

    @Override
    public void drawImageRotated(
            GameImage image, double centerX, double centerY, double angleDegrees) {
        BufferedImage bufferedImage = bufferedImage(image);
        AffineTransform original = graphics.getTransform();
        try {
            graphics.translate(pixel(centerX), pixel(centerY));
            graphics.rotate(Math.toRadians(angleDegrees));
            graphics.drawImage(
                    bufferedImage,
                    -bufferedImage.getWidth() / 2,
                    -bufferedImage.getHeight() / 2,
                    null);
        } finally {
            graphics.setTransform(original);
        }
    }

    @Override
    public int width() {
        return surface.getWidth();
    }

    @Override
    public int height() {
        return surface.getHeight();
    }

    private static int pixel(double coordinate) {
        return (int) Math.round(coordinate);
    }

    private static Graphics2D createGraphics(BufferedImage surface) {
        Objects.requireNonNull(surface, "La superficie no puede ser nula.");
        return surface.createGraphics();
    }

    private static java.awt.Color toAwtColor(Color color) {
        Objects.requireNonNull(color, "El color no puede ser nulo.");
        return new java.awt.Color(color.red(), color.green(), color.blue());
    }

    private static BufferedImage bufferedImage(GameImage image) {
        Objects.requireNonNull(image, "La imagen no puede ser nula.");
        if (!(image instanceof BufferedGameImage bufferedGameImage)) {
            throw new IllegalArgumentException("La imagen no pertenece al motor gráfico de GameLab.");
        }
        return bufferedGameImage.bufferedImage();
    }
}
