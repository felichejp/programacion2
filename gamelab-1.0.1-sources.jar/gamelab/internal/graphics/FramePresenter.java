package gamelab.internal.graphics;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.util.Objects;

final class FramePresenter {
    private FramePresenter() {
    }

    static void present(
            BufferedImage frame,
            BufferStrategy bufferStrategy,
            int physicalWidth,
            int physicalHeight) {
        Objects.requireNonNull(frame, "El cuadro no puede ser nulo.");
        Objects.requireNonNull(bufferStrategy, "La estrategia de búfer no puede ser nula.");
        Viewport viewport = Viewport.fit(
                frame.getWidth(), frame.getHeight(), physicalWidth, physicalHeight);

        do {
            Graphics graphics = bufferStrategy.getDrawGraphics();
            try {
                Graphics2D graphics2D = (Graphics2D) graphics;
                graphics2D.setColor(java.awt.Color.BLACK);
                graphics2D.fillRect(0, 0, physicalWidth, physicalHeight);
                graphics2D.drawImage(
                        frame,
                        viewport.x(),
                        viewport.y(),
                        viewport.width(),
                        viewport.height(),
                        null);
            } finally {
                graphics.dispose();
            }
        } while (bufferStrategy.contentsRestored());

        if (!bufferStrategy.contentsLost()) {
            bufferStrategy.show();
        }
    }
}
