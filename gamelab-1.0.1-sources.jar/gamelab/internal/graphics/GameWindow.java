package gamelab.internal.graphics;

import gamelab.errors.GameExecutionException;
import gamelab.internal.input.KeyboardState;
import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.lang.reflect.InvocationTargetException;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/** Ventana Swing interna creada y cerrada exclusivamente en el EDT. */
final class GameWindow {
    private final JFrame frame;
    private final Canvas canvas;
    private final BufferStrategy bufferStrategy;
    private final AtomicBoolean closed = new AtomicBoolean();

    GameWindow(
            String title,
            int logicalWidth,
            int logicalHeight,
            KeyboardState keyboard,
            Runnable requestStop) {
        Objects.requireNonNull(keyboard, "El teclado no puede ser nulo.");
        Objects.requireNonNull(requestStop, "La solicitud de cierre no puede ser nula.");
        WindowParts parts = createOnEdt(
                title, logicalWidth, logicalHeight, keyboard, requestStop);
        frame = parts.frame();
        canvas = parts.canvas();
        bufferStrategy = parts.bufferStrategy();
    }

    void present(BufferedImage image) {
        FramePresenter.present(
                image,
                bufferStrategy,
                Math.max(1, canvas.getWidth()),
                Math.max(1, canvas.getHeight()));
    }

    void close() {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        Runnable closeWindow = frame::dispose;
        if (SwingUtilities.isEventDispatchThread()) {
            closeWindow.run();
        } else {
            SwingUtilities.invokeLater(closeWindow);
        }
    }

    private static WindowParts createOnEdt(
            String title,
            int logicalWidth,
            int logicalHeight,
            KeyboardState keyboard,
            Runnable requestStop) {
        return createOnEdt(
                new SwingEdtAccess(),
                creation -> createWindow(
                        creation, title, logicalWidth, logicalHeight, keyboard, requestStop));
    }

    static WindowParts createOnEdt(EdtAccess edt, WindowInitializer initializer) {
        Objects.requireNonNull(edt, "El acceso al EDT no puede ser nulo.");
        Objects.requireNonNull(initializer, "La inicialización no puede ser nula.");
        WindowCreation creation = new WindowCreation();
        Runnable initialize = () -> initializer.initialize(creation);

        try {
            if (edt.isEventDispatchThread()) {
                initialize.run();
            } else {
                edt.invokeAndWait(initialize);
            }
            return creation.parts();
        } catch (InterruptedException interruption) {
            cleanupOnEdt(edt, creation);
            Thread.currentThread().interrupt();
            throw new GameExecutionException("No se pudo crear la ventana del juego.", interruption);
        } catch (InvocationTargetException invocationFailure) {
            cleanupOnEdt(edt, creation);
            throw new GameExecutionException(
                    "No se pudo crear la ventana del juego.", invocationFailure.getCause());
        } catch (RuntimeException | Error cause) {
            cleanupOnEdt(edt, creation);
            throw new GameExecutionException("No se pudo crear la ventana del juego.", cause);
        }
    }

    private static void cleanupOnEdt(EdtAccess edt, WindowCreation creation) {
        if (edt.isEventDispatchThread()) {
            creation.cleanupOnce();
        } else {
            edt.invokeLater(creation::cleanupOnce);
        }
    }

    private static void createWindow(
            WindowCreation creation,
            String title,
            int logicalWidth,
            int logicalHeight,
            KeyboardState keyboard,
            Runnable requestStop) {
        JFrame frame = new JFrame(title);
        creation.registerCleanup(frame::dispose);
        Canvas canvas = new Canvas();
        canvas.setPreferredSize(new Dimension(logicalWidth, logicalHeight));
        canvas.setIgnoreRepaint(true);
        installListeners(frame, canvas, keyboard, requestStop);

        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.add(canvas);
        frame.pack();
        frame.setMinimumSize(new Dimension(
                Math.max(1, logicalWidth / 2), Math.max(1, logicalHeight / 2)));
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        canvas.createBufferStrategy(2);
        canvas.requestFocusInWindow();
        creation.complete(new WindowParts(frame, canvas, canvas.getBufferStrategy()));
    }

    private static void installListeners(
            JFrame frame,
            Canvas canvas,
            KeyboardState keyboard,
            Runnable requestStop) {
        canvas.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent event) {
                keyboard.press(event.getKeyCode());
            }

            @Override
            public void keyReleased(KeyEvent event) {
                keyboard.release(event.getKeyCode());
            }
        });
        canvas.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent event) {
                keyboard.clear();
            }
        });
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent event) {
                requestStop.run();
            }
        });
    }

    interface EdtAccess {
        boolean isEventDispatchThread();

        void invokeAndWait(Runnable task) throws InterruptedException, InvocationTargetException;

        void invokeLater(Runnable task);
    }

    @FunctionalInterface
    interface WindowInitializer {
        void initialize(WindowCreation creation);
    }

    static final class WindowCreation {
        private Runnable cleanup;
        private WindowParts parts;
        private boolean cleanupRequested;
        private boolean cleanupCompleted;

        synchronized void registerCleanup(Runnable cleanup) {
            if (this.cleanup != null) {
                throw new IllegalStateException("La limpieza de la ventana ya fue registrada.");
            }
            this.cleanup = Objects.requireNonNull(cleanup, "La limpieza no puede ser nula.");
            runCleanupIfReady();
        }

        synchronized void complete(WindowParts parts) {
            this.parts = Objects.requireNonNull(parts, "La ventana creada no puede ser nula.");
        }

        synchronized WindowParts parts() {
            if (parts == null) {
                throw new IllegalStateException("La creación de la ventana no se completó.");
            }
            return parts;
        }

        synchronized void cleanupOnce() {
            cleanupRequested = true;
            runCleanupIfReady();
        }

        private void runCleanupIfReady() {
            if (cleanupRequested && cleanup != null && !cleanupCompleted) {
                cleanupCompleted = true;
                cleanup.run();
            }
        }
    }

    private static final class SwingEdtAccess implements EdtAccess {
        @Override
        public boolean isEventDispatchThread() {
            return SwingUtilities.isEventDispatchThread();
        }

        @Override
        public void invokeAndWait(Runnable task)
                throws InterruptedException, InvocationTargetException {
            SwingUtilities.invokeAndWait(task);
        }

        @Override
        public void invokeLater(Runnable task) {
            SwingUtilities.invokeLater(task);
        }
    }

    record WindowParts(JFrame frame, Canvas canvas, BufferStrategy bufferStrategy) {
    }
}
