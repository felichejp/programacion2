package gamelab.internal.graphics;

import gamelab.errors.ResourceException;
import gamelab.graphics.GameImage;
import gamelab.resources.Images;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;

/**
 * Carga interna de imágenes mediante las bibliotecas gráficas del JDK.
 */
public final class InternalImages {
    private InternalImages() {
    }

    /**
     * Carga una imagen PNG desde el classpath.
     *
     * @param path ruta absoluta del recurso
     * @return imagen cargada
     * @throws ResourceException si el recurso falta, es inválido o no puede leerse
     */
    public static GameImage load(String path) {
        try (InputStream stream = Images.class.getResourceAsStream(path)) {
            if (stream == null) {
                throw new ResourceException(messageFor(path, "no se encontró"));
            }

            BufferedImage image = ImageIO.read(stream);
            if (image == null) {
                throw new ResourceException(messageFor(path, "no contiene una imagen PNG válida"));
            }
            return new BufferedGameImage(image);
        } catch (IOException exception) {
            throw new ResourceException(messageFor(path, "no pudo leerse"), exception);
        }
    }

    private static String messageFor(String path, String problem) {
        return "El recurso " + path + " " + problem
                + ". Verifica que esté en la carpeta de recursos.";
    }
}
