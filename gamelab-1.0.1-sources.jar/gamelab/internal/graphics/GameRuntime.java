package gamelab.internal.graphics;

import gamelab.graphics.GameCanvas;
import gamelab.input.Input;
import gamelab.internal.FixedStepLoop;
import gamelab.internal.NanoClock;
import java.util.function.BooleanSupplier;

/**
 * Fachada interna que conecta la API pública con el motor sin exponer tipos de AWT o Swing.
 */
public final class GameRuntime {
    private GameRuntime() {
    }

    /** Operaciones del juego que el motor invoca desde su hilo dedicado. */
    public interface Lifecycle {
        /** Ejecuta la inicialización del juego. */
        void start();

        /**
         * Ejecuta una actualización con su instantánea de entrada.
         *
         * @param input teclado capturado para esta actualización
         */
        void update(Input input);

        /**
         * Dibuja el cuadro lógico actual.
         *
         * @param canvas superficie lógica del juego
         */
        void draw(GameCanvas canvas);
    }

    /** Estrategia inyectable para ejecutar un juego con o sin ventana. */
    @FunctionalInterface
    public interface Runner {
        /**
         * Ejecuta el motor hasta que se solicite detenerlo.
         *
         * @param title título de la ventana
         * @param width ancho lógico
         * @param height alto lógico
         * @param lifecycle callbacks del juego
         * @param running consulta de ejecución
         * @param requestStop solicitud de terminación
         */
        void run(
                String title,
                int width,
                int height,
                Lifecycle lifecycle,
                BooleanSupplier running,
                Runnable requestStop);
    }

    /**
     * Crea la estrategia normal respaldada por una ventana.
     *
     * @return estrategia de ejecución con ventana
     */
    public static Runner windowed() {
        return (title, width, height, lifecycle, running, requestStop) ->
                new GameEngine(
                                title,
                                width,
                                height,
                                lifecycle,
                                running,
                                requestStop,
                                System::nanoTime,
                                0,
                                true)
                        .run();
    }

    /**
     * Crea una estrategia determinista sin ventana para pruebas del motor.
     *
     * @param frameLimit número de pares de actualización y dibujo que se ejecutarán
     * @return estrategia de ejecución sin ventana
     */
    public static Runner headless(int frameLimit) {
        if (frameLimit <= 0) {
            throw new IllegalArgumentException("El límite de cuadros debe ser positivo.");
        }
        return (title, width, height, lifecycle, running, requestStop) -> {
            NanoClock clock = new StepClock();
            new GameEngine(
                            title,
                            width,
                            height,
                            lifecycle,
                            running,
                            requestStop,
                            clock,
                            frameLimit,
                            false)
                    .run();
        };
    }

    private static final class StepClock implements NanoClock {
        private long now;

        @Override
        public long nanoTime() {
            long current = now;
            now += FixedStepLoop.STEP_NANOS;
            return current;
        }
    }
}
