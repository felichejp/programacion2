package gamelab.internal.graphics;

import gamelab.graphics.GameImage;
import java.awt.image.BufferedImage;
import java.util.Objects;

/**
 * Adaptador interno de una imagen de Java2D para la API de GameLab.
 */
final class BufferedGameImage implements GameImage {
    private final BufferedImage image;

    BufferedGameImage(BufferedImage image) {
        this.image = Objects.requireNonNull(image, "La imagen no puede ser nula.");
    }

    @Override
    public int width() {
        return image.getWidth();
    }

    @Override
    public int height() {
        return image.getHeight();
    }

    BufferedImage bufferedImage() {
        return image;
    }
}
