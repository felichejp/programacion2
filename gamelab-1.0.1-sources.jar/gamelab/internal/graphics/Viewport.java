package gamelab.internal.graphics;

record Viewport(int x, int y, int width, int height) {

    static Viewport fit(
            int logicalWidth, int logicalHeight, int physicalWidth, int physicalHeight) {
        requirePositive(logicalWidth, "El ancho lógico");
        requirePositive(logicalHeight, "El alto lógico");
        requirePositive(physicalWidth, "El ancho físico");
        requirePositive(physicalHeight, "El alto físico");

        double scale = Math.min(
                (double) physicalWidth / logicalWidth,
                (double) physicalHeight / logicalHeight);
        int width = (int) Math.round(logicalWidth * scale);
        int height = (int) Math.round(logicalHeight * scale);
        int x = (physicalWidth - width) / 2;
        int y = (physicalHeight - height) / 2;
        return new Viewport(x, y, width, height);
    }

    private static void requirePositive(int dimension, String name) {
        if (dimension <= 0) {
            throw new IllegalArgumentException(name + " debe ser positivo.");
        }
    }
}
