package gamelab.internal;

/** Reloj monotónico inyectable usado por el ciclo fijo. */
@FunctionalInterface
public interface NanoClock {

    /**
     * Obtiene el instante actual del reloj.
     *
     * @return instante monotónico en nanosegundos
     */
    long nanoTime();
}
