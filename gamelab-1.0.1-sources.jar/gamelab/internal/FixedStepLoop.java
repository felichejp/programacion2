package gamelab.internal;

import java.util.Objects;
import java.util.concurrent.locks.LockSupport;
import java.util.function.BooleanSupplier;

/** Ejecuta pares de actualización y dibujo a una frecuencia fija. */
public final class FixedStepLoop {
    /** Duración entera de uno de los 60 pasos lógicos por segundo. */
    public static final long STEP_NANOS = 1_000_000_000L / 60L;

    private static final int MAX_CATCH_UP_STEPS = 5;

    private final NanoClock clock;
    private final Runnable update;
    private final Runnable draw;
    private final BooleanSupplier running;
    private long previousTime;
    private long accumulator;

    /**
     * Crea un ciclo con dependencias inyectables para permitir pruebas deterministas.
     *
     * @param clock reloj monotónico
     * @param update actualización que se ejecutará por cada paso
     * @param draw dibujo que se ejecutará después de cada actualización
     * @param running consulta que indica si el ciclo debe continuar
     */
    public FixedStepLoop(
            NanoClock clock, Runnable update, Runnable draw, BooleanSupplier running) {
        this.clock = Objects.requireNonNull(clock, "El reloj no puede ser nulo.");
        this.update = Objects.requireNonNull(update, "La actualización no puede ser nula.");
        this.draw = Objects.requireNonNull(draw, "El dibujo no puede ser nulo.");
        this.running = Objects.requireNonNull(running, "La bandera de ejecución no puede ser nula.");
        previousTime = clock.nanoTime();
    }

    /** Ejecuta iteraciones hasta que se solicite detener el juego. */
    public void run() {
        while (running.getAsBoolean()) {
            iterate();
        }
    }

    /** Acumula el tiempo transcurrido y ejecuta los pasos completos disponibles. */
    public void iterate() {
        if (!running.getAsBoolean()) {
            return;
        }

        long currentTime = clock.nanoTime();
        long elapsed = currentTime - previousTime;
        previousTime = currentTime;
        if (elapsed > 0) {
            accumulator += elapsed;
        }

        int completedSteps = 0;
        while (accumulator >= STEP_NANOS
                && completedSteps < MAX_CATCH_UP_STEPS
                && running.getAsBoolean()) {
            update.run();
            draw.run();
            accumulator -= STEP_NANOS;
            completedSteps++;
        }

        if (completedSteps == MAX_CATCH_UP_STEPS && accumulator >= STEP_NANOS) {
            accumulator %= STEP_NANOS;
        }

        if (running.getAsBoolean() && accumulator < STEP_NANOS) {
            LockSupport.parkNanos(STEP_NANOS - accumulator);
        }
    }
}
