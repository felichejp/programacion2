package gamelab.input;

import java.util.Objects;
import java.util.Set;

/**
 * Instantánea inmutable del teclado durante una actualización del juego.
 *
 * <p>{@link #isKeyDown(Key)} sirve para movimiento continuo y
 * {@link #isKeyPressed(Key)} para una acción única por pulsación. Por ejemplo,
 * {@code input.isKeyPressed(Key.SPACE)} es apropiado para disparar una vez.</p>
 */
public final class Input {
    private final Set<Key> down;
    private final Set<Key> pressed;

    /**
     * Crea una instantánea defensiva del estado indicado.
     *
     * Este constructor resulta útil en pruebas; durante un juego se obtiene la instantánea
     * mediante el método protegido {@code Game.input()}.
     *
     * @param down teclas mantenidas durante este paso
     * @param pressed teclas cuya transición de liberada a pulsada ocurrió en este paso
     * @throws NullPointerException si un conjunto o alguna tecla es nula
     */
    public Input(Set<Key> down, Set<Key> pressed) {
        this.down = Set.copyOf(Objects.requireNonNull(down, "Las teclas mantenidas no pueden ser nulas."));
        this.pressed = Set.copyOf(Objects.requireNonNull(pressed, "Las teclas pulsadas no pueden ser nulas."));
    }

    /**
     * Indica si una tecla permanece mantenida.
     *
     * @param key tecla que se consultará
     * @return {@code true} en cada actualización mientras la tecla permanezca mantenida
     * @throws NullPointerException si {@code key} es nula
     */
    public boolean isKeyDown(Key key) {
        return down.contains(Objects.requireNonNull(key, "La tecla no puede ser nula."));
    }

    /**
     * Indica si una tecla se pulsó desde la instantánea anterior.
     *
     * @param key tecla que se consultará
     * @return {@code true} solo en la primera actualización tras pulsarla; mantener la tecla
     *         no vuelve a producir {@code true}
     * @throws NullPointerException si {@code key} es nula
     */
    public boolean isKeyPressed(Key key) {
        return pressed.contains(Objects.requireNonNull(key, "La tecla no puede ser nula."));
    }
}
