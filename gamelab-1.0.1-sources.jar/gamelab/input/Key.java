package gamelab.input;

/**
 * Teclas que un juego puede consultar mediante {@link Input}.
 * Por ejemplo, {@code input.isKeyDown(Key.LEFT)} permite mover un objeto continuamente.
 */
public enum Key {
    /** Letra A. */
    A,
    /** Letra B. */
    B,
    /** Letra C. */
    C,
    /** Letra D. */
    D,
    /** Letra E. */
    E,
    /** Letra F. */
    F,
    /** Letra G. */
    G,
    /** Letra H. */
    H,
    /** Letra I. */
    I,
    /** Letra J. */
    J,
    /** Letra K. */
    K,
    /** Letra L. */
    L,
    /** Letra M. */
    M,
    /** Letra N. */
    N,
    /** Letra O. */
    O,
    /** Letra P. */
    P,
    /** Letra Q. */
    Q,
    /** Letra R. */
    R,
    /** Letra S. */
    S,
    /** Letra T. */
    T,
    /** Letra U. */
    U,
    /** Letra V. */
    V,
    /** Letra W. */
    W,
    /** Letra X. */
    X,
    /** Letra Y. */
    Y,
    /** Letra Z. */
    Z,
    /** Dígito 0 de la fila numérica principal. */
    NUM_0,
    /** Dígito 1 de la fila numérica principal. */
    NUM_1,
    /** Dígito 2 de la fila numérica principal. */
    NUM_2,
    /** Dígito 3 de la fila numérica principal. */
    NUM_3,
    /** Dígito 4 de la fila numérica principal. */
    NUM_4,
    /** Dígito 5 de la fila numérica principal. */
    NUM_5,
    /** Dígito 6 de la fila numérica principal. */
    NUM_6,
    /** Dígito 7 de la fila numérica principal. */
    NUM_7,
    /** Dígito 8 de la fila numérica principal. */
    NUM_8,
    /** Dígito 9 de la fila numérica principal. */
    NUM_9,
    /** Flecha arriba. */
    UP,
    /** Flecha abajo. */
    DOWN,
    /** Flecha izquierda. */
    LEFT,
    /** Flecha derecha. */
    RIGHT,
    /** Barra espaciadora. */
    SPACE,
    /** Tecla Intro o Enter. */
    ENTER,
    /** Tecla Escape. */
    ESCAPE,
    /** Cualquier tecla Mayús o Shift. */
    SHIFT,
    /** Cualquier tecla Control. */
    CONTROL,
    /** Cualquier tecla Alt. */
    ALT
}
