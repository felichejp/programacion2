package gamelab.errors;

/**
 * Indica que la configuración de un juego no permite iniciarlo.
 * Por ejemplo, {@code new Game("", 800, 600) { ... }} falla por tener un título vacío.
 */
public final class GameConfigurationException extends GameLabException {

    /**
     * Crea una excepción con la descripción del problema.
     *
     * @param message descripción del problema de configuración
     */
    public GameConfigurationException(String message) {
        super(message);
    }

    /**
     * Crea una excepción con la descripción y causa indicadas.
     *
     * @param message descripción del problema de configuración
     * @param cause causa original
     */
    public GameConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }
}
