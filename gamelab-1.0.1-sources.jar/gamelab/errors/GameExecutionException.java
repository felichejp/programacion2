package gamelab.errors;

/**
 * Indica que el juego falló durante una fase de su ejecución.
 * Por ejemplo, una excepción lanzada por {@code update()} se conserva como causa y el mensaje
 * identifica esa fase.
 */
public final class GameExecutionException extends GameLabException {

    /**
     * Crea una excepción con la descripción del fallo.
     *
     * @param message descripción del fallo
     */
    public GameExecutionException(String message) {
        super(message);
    }

    /**
     * Crea una excepción que conserva el fallo original.
     *
     * @param message descripción del fallo
     * @param cause fallo original
     */
    public GameExecutionException(String message, Throwable cause) {
        super(message, cause);
    }
}
