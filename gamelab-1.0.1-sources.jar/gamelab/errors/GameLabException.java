package gamelab.errors;

/**
 * Excepción base no comprobada para los errores informados por GameLab.
 *
 * <p>Permite manejar en un solo bloque los fallos de configuración, ejecución y recursos:
 * {@code catch (GameLabException error) { ... }}.</p>
 */
public class GameLabException extends RuntimeException {

    /**
     * Crea una excepción con el mensaje indicado.
     *
     * @param message descripción del problema
     */
    public GameLabException(String message) {
        super(message);
    }

    /**
     * Crea una excepción con el mensaje y la causa indicados.
     *
     * @param message descripción del problema
     * @param cause causa original del problema
     */
    public GameLabException(String message, Throwable cause) {
        super(message, cause);
    }
}
