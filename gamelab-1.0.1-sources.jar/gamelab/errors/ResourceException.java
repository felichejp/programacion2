package gamelab.errors;

/**
 * Indica que no fue posible cargar un recurso de GameLab.
 * Por ejemplo, {@code Images.load("/images/no-existe.png")} informa la ruta ausente mediante
 * esta excepción.
 */
public final class ResourceException extends GameLabException {

    /**
     * Crea una excepción con el mensaje indicado.
     *
     * @param message descripción del problema con el recurso
     */
    public ResourceException(String message) {
        super(message);
    }

    /**
     * Crea una excepción con el mensaje y la causa indicados.
     *
     * @param message descripción del problema con el recurso
     * @param cause causa original del problema
     */
    public ResourceException(String message, Throwable cause) {
        super(message, cause);
    }
}
