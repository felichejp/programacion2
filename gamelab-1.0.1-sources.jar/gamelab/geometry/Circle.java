package gamelab.geometry;

/**
 * Círculo inmutable definido por su centro y radio.
 *
 * <p>Sus valores suelen expresarse en píxeles lógicos. Por ejemplo,
 * {@code new Circle(100, 80, 20)} tiene centro en {@code (100, 80)} y diámetro 40.</p>
 *
 * @param centerX coordenada horizontal del centro
 * @param centerY coordenada vertical del centro
 * @param radius radio no negativo
 */
public record Circle(double centerX, double centerY, double radius) {

    /**
     * Valida el radio del círculo.
     *
     * @throws IllegalArgumentException si el radio es negativo
     */
    public Circle {
        if (radius < 0) {
            throw new IllegalArgumentException("El radio no puede ser negativo.");
        }
    }
}
