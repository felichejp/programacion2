package gamelab.geometry;

/**
 * Operaciones puras para comprobar colisiones entre figuras geométricas.
 *
 * <p>Las figuras deben compartir el mismo sistema de coordenadas y unidades. El contacto exacto
 * entre bordes cuenta como colisión; por ejemplo, dos rectángulos adyacentes que comparten una
 * arista producen {@code true}.</p>
 */
public final class Collision {

    private Collision() {
    }

    /**
     * Indica si dos rectángulos se superponen o se tocan en el borde.
     *
     * @param first primer rectángulo
     * @param second segundo rectángulo
     * @return {@code true} cuando las figuras comparten al menos un punto
     * @throws NullPointerException si alguna figura es nula
     */
    public static boolean overlaps(Rectangle first, Rectangle second) {
        return first.x() <= second.x() + second.width()
                && first.x() + first.width() >= second.x()
                && first.y() <= second.y() + second.height()
                && first.y() + first.height() >= second.y();
    }

    /**
     * Indica si dos círculos se superponen o se tocan en el borde.
     *
     * @param first primer círculo
     * @param second segundo círculo
     * @return {@code true} cuando las figuras comparten al menos un punto
     * @throws NullPointerException si alguna figura es nula
     */
    public static boolean overlaps(Circle first, Circle second) {
        double dx = first.centerX() - second.centerX();
        double dy = first.centerY() - second.centerY();
        double radii = first.radius() + second.radius();
        return dx * dx + dy * dy <= radii * radii;
    }

    /**
     * Indica si un círculo se superpone o toca un rectángulo.
     *
     * @param circle círculo que se comprueba
     * @param rectangle rectángulo que se comprueba
     * @return {@code true} cuando las figuras comparten al menos un punto
     * @throws NullPointerException si alguna figura es nula
     */
    public static boolean overlaps(Circle circle, Rectangle rectangle) {
        double closestX = Math.max(rectangle.x(),
                Math.min(circle.centerX(), rectangle.x() + rectangle.width()));
        double closestY = Math.max(rectangle.y(),
                Math.min(circle.centerY(), rectangle.y() + rectangle.height()));
        double dx = circle.centerX() - closestX;
        double dy = circle.centerY() - closestY;
        return dx * dx + dy * dy <= circle.radius() * circle.radius();
    }

    /**
     * Indica si un rectángulo contiene un punto, incluidos sus bordes.
     *
     * @param rectangle rectángulo que se comprueba
     * @param point punto que se comprueba
     * @return {@code true} cuando el punto pertenece al rectángulo
     * @throws NullPointerException si la figura o el punto es nulo
     */
    public static boolean contains(Rectangle rectangle, Point point) {
        return point.x() >= rectangle.x()
                && point.x() <= rectangle.x() + rectangle.width()
                && point.y() >= rectangle.y()
                && point.y() <= rectangle.y() + rectangle.height();
    }
}
