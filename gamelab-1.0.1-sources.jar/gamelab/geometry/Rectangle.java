package gamelab.geometry;

/**
 * Rectángulo inmutable definido por su esquina superior izquierda y sus dimensiones.
 *
 * <p>Las cuatro cantidades suelen expresarse en píxeles lógicos. Por ejemplo,
 * {@code new Rectangle(10, 20, 80, 40)} ocupa desde {@code (10, 20)} hasta
 * {@code (90, 60)}, incluidos sus bordes.</p>
 *
 * @param x coordenada horizontal de la esquina superior izquierda
 * @param y coordenada vertical de la esquina superior izquierda
 * @param width ancho no negativo
 * @param height alto no negativo
 */
public record Rectangle(double x, double y, double width, double height) {

    /**
     * Valida las dimensiones del rectángulo.
     *
     * @throws IllegalArgumentException si el ancho o el alto es negativo
     */
    public Rectangle {
        if (width < 0 || height < 0) {
            throw new IllegalArgumentException("El ancho y el alto no pueden ser negativos.");
        }
    }
}
