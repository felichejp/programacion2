package gamelab.geometry;

/**
 * Punto inmutable en el sistema de coordenadas lógico de GameLab.
 *
 * <p>Las coordenadas suelen medirse en píxeles lógicos desde la esquina superior izquierda.
 * Por ejemplo, {@code new Point(10, 20)} está 10 píxeles a la derecha y 20 hacia abajo.</p>
 *
 * @param x coordenada horizontal, normalmente en píxeles lógicos
 * @param y coordenada vertical, normalmente en píxeles lógicos
 */
public record Point(double x, double y) {
}
