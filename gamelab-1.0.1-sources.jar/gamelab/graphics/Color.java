package gamelab.graphics;

/**
 * Color RGB inmutable para usar en los dibujos de GameLab.
 *
 * <p>Cada componente usa ocho bits. Por ejemplo, {@code new Color(255, 128, 0)} representa
 * naranja. También se ofrecen constantes como {@link #BLACK} y {@link #WHITE}.</p>
 *
 * @param red componente roja, entre 0 y 255
 * @param green componente verde, entre 0 y 255
 * @param blue componente azul, entre 0 y 255
 */
public record Color(int red, int green, int blue) {

    /** Color blanco. */
    public static final Color WHITE = new Color(255, 255, 255);
    /** Color negro. */
    public static final Color BLACK = new Color(0, 0, 0);
    /** Color rojo. */
    public static final Color RED = new Color(255, 0, 0);
    /** Color verde. */
    public static final Color GREEN = new Color(0, 255, 0);
    /** Color azul. */
    public static final Color BLUE = new Color(0, 0, 255);
    /** Color amarillo. */
    public static final Color YELLOW = new Color(255, 255, 0);
    /** Color gris. */
    public static final Color GRAY = new Color(128, 128, 128);

    /**
     * Valida que las tres componentes pertenezcan al intervalo RGB válido.
     *
     * @throws IllegalArgumentException si alguna componente está fuera de 0 a 255
     */
    public Color {
        validateComponent(red, "roja");
        validateComponent(green, "verde");
        validateComponent(blue, "azul");
    }

    private static void validateComponent(int component, String name) {
        if (component < 0 || component > 255) {
            throw new IllegalArgumentException("La componente " + name + " debe estar entre 0 y 255.");
        }
    }
}
