package gamelab.graphics;

/**
 * Superficie de dibujo independiente de la biblioteca gráfica subyacente.
 *
 * <p>El origen {@code (0, 0)} está en la esquina superior izquierda; {@code x} aumenta hacia
 * la derecha y {@code y}, hacia abajo. Coordenadas y dimensiones se expresan en píxeles lógicos
 * y pueden ser decimales. El contenido que queda fuera de la superficie se recorta.</p>
 *
 * <p>Ejemplo: {@code canvas.setColor(Color.YELLOW);} seguido de
 * {@code canvas.fillCircle(100, 80, 20);} dibuja un círculo amarillo.</p>
 */
public interface GameCanvas {

    /**
     * Limpia toda la superficie con un color sin cambiar el color de dibujo.
     *
     * @param color color de fondo
     * @throws NullPointerException si {@code color} es nulo
     */
    void clear(Color color);

    /**
     * Establece el color de las figuras, líneas y textos posteriores.
     *
     * @param color nuevo color de dibujo
     * @throws NullPointerException si {@code color} es nulo
     */
    void setColor(Color color);

    /**
     * Dibuja el contorno de un rectángulo con el color actual.
     *
     * @param x coordenada horizontal de la esquina superior izquierda, en píxeles lógicos
     * @param y coordenada vertical de la esquina superior izquierda, en píxeles lógicos
     * @param width ancho, en píxeles lógicos
     * @param height alto, en píxeles lógicos
     */
    void drawRectangle(double x, double y, double width, double height);

    /**
     * Dibuja un rectángulo relleno con el color actual.
     *
     * @param x coordenada horizontal de la esquina superior izquierda, en píxeles lógicos
     * @param y coordenada vertical de la esquina superior izquierda, en píxeles lógicos
     * @param width ancho, en píxeles lógicos
     * @param height alto, en píxeles lógicos
     */
    void fillRectangle(double x, double y, double width, double height);

    /**
     * Dibuja el contorno de un círculo con el color actual.
     *
     * @param centerX coordenada horizontal del centro, en píxeles lógicos
     * @param centerY coordenada vertical del centro, en píxeles lógicos
     * @param radius radio, en píxeles lógicos
     */
    void drawCircle(double centerX, double centerY, double radius);

    /**
     * Dibuja un círculo relleno con el color actual.
     *
     * @param centerX coordenada horizontal del centro, en píxeles lógicos
     * @param centerY coordenada vertical del centro, en píxeles lógicos
     * @param radius radio, en píxeles lógicos
     */
    void fillCircle(double centerX, double centerY, double radius);

    /**
     * Dibuja una línea entre dos puntos con el color actual.
     *
     * @param x1 coordenada horizontal del primer punto, en píxeles lógicos
     * @param y1 coordenada vertical del primer punto, en píxeles lógicos
     * @param x2 coordenada horizontal del segundo punto, en píxeles lógicos
     * @param y2 coordenada vertical del segundo punto, en píxeles lógicos
     */
    void drawLine(double x1, double y1, double x2, double y2);

    /**
     * Dibuja texto con una fuente sans serif y el color actual. La coordenada {@code y}
     * corresponde a la línea base del texto, no a su borde superior.
     *
     * @param text texto que se dibujará
     * @param x coordenada horizontal inicial, en píxeles lógicos
     * @param y coordenada vertical de la línea base, en píxeles lógicos
     * @param size tamaño entero de la fuente, en puntos
     * @throws NullPointerException si {@code text} es nulo
     */
    void drawText(String text, double x, double y, int size);

    /**
     * Dibuja una imagen con sus dimensiones originales y ubica su esquina superior izquierda.
     *
     * @param image imagen PNG cargada por GameLab
     * @param x coordenada horizontal de la esquina superior izquierda, en píxeles lógicos
     * @param y coordenada vertical de la esquina superior izquierda, en píxeles lógicos
     * @throws NullPointerException si {@code image} es nula
     * @throws IllegalArgumentException si la imagen no fue creada por GameLab
     */
    void drawImage(GameImage image, double x, double y);

    /**
     * Dibuja una imagen escalada a las dimensiones indicadas.
     *
     * @param image imagen PNG cargada por GameLab
     * @param x coordenada horizontal de la esquina superior izquierda, en píxeles lógicos
     * @param y coordenada vertical de la esquina superior izquierda, en píxeles lógicos
     * @param width ancho de destino, en píxeles lógicos
     * @param height alto de destino, en píxeles lógicos
     * @throws NullPointerException si {@code image} es nula
     * @throws IllegalArgumentException si la imagen no fue creada por GameLab
     */
    void drawImage(GameImage image, double x, double y, double width, double height);

    /**
     * Dibuja una imagen con sus dimensiones originales, centrada y girada. Un ángulo positivo
     * se ve en sentido horario porque el eje vertical crece hacia abajo.
     *
     * @param image imagen PNG cargada por GameLab
     * @param centerX coordenada horizontal del centro, en píxeles lógicos
     * @param centerY coordenada vertical del centro, en píxeles lógicos
     * @param angleDegrees ángulo de rotación, en grados
     * @throws NullPointerException si {@code image} es nula
     * @throws IllegalArgumentException si la imagen no fue creada por GameLab
     */
    void drawImageRotated(GameImage image, double centerX, double centerY, double angleDegrees);

    /**
     * Obtiene el ancho de la superficie en píxeles.
     *
     * @return ancho positivo de la superficie, en píxeles lógicos
     */
    int width();

    /**
     * Obtiene la altura de la superficie en píxeles.
     *
     * @return altura positiva de la superficie, en píxeles lógicos
     */
    int height();
}
