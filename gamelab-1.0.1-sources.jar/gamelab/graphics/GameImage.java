package gamelab.graphics;

/**
 * Imagen PNG cargada y lista para dibujarse con un {@link GameCanvas}.
 *
 * <p>Sus dimensiones se expresan en píxeles. Por ejemplo, una imagen obtenida mediante
 * {@code gamelab.resources.Images.load("/images/nave.png")} puede dibujarse con
 * {@link GameCanvas#drawImage(GameImage, double, double)}.</p>
 */
public interface GameImage {

    /**
     * Obtiene el ancho de la imagen en píxeles.
     *
     * @return ancho de la imagen
     */
    int width();

    /**
     * Obtiene la altura de la imagen en píxeles.
     *
     * @return altura de la imagen
     */
    int height();
}
